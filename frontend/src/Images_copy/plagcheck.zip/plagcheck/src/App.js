import React from "react";
import TeacherHome from "./Components/TeacherHome";
import TeacherSecond from "./Components/TeacherSecond";
import TeacherThird from "./Components/TeacherThird";
import Home from "./Components/Home";
import StudentHome from "./Components/StudentHome";
import StudentSecond from "./Components/StudentSecond";

function App() {
  return (
    <div>
      {/* <Home /> */}
      {/* <StudentHome /> */}
      {/* <TeacherHome /> */}
      {/* <StudentSecond /> */}
      {/* <TeacherSecond /> */}
      <TeacherThird />
    </div>
  );
}

export default App;
