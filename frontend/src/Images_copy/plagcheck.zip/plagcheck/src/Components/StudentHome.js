import React, { useState } from "react";
import "../Css/studenthome.css";
import CourseList from "./CourseList";
import CourseData from "./CourseData";

const StudentHome = () => {
  const [course, setCourse] = useState(CourseList);
  return (
    <section className="student-home">
      <div className="project-heading">Plag Check</div>
      <button className="btn1">Join Class</button>
      <button>Open</button>
      <CourseData course={course} />
      <button className="btn2">Analyze Submission</button>
    </section>
  );
};

export default StudentHome;
