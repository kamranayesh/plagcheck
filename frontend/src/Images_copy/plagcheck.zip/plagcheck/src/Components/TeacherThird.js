import React from "react";
const TeacherThird = () => {
  return (
    <section className="student-home">
      <div className="project-heading">Plag Check</div>
      <button>View</button>
      <button>Grade</button>
      
    </section>
  );
};

export default TeacherThird;