import React from "react";
const TeacherHome = () => {
  return (
    <section className="student-home">
      <div className="project-heading">Plag Check</div>
      <button className="btn1">New Class</button>
      <button>Open</button>
    </section>
  );
};

export default TeacherHome;
