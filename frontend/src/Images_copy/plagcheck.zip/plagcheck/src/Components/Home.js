import React from "react";
import "../Css/home.css";
const Home = () => {
  return (
    <section className="home">
      <div className="project-heading">Plag Check</div>
      <button className="btn1">Login</button>
      <button className="btn2">Register</button>
      <div>
        <h3>Short Description</h3>
        <button className="guest-btn">Use As Guest</button>
      </div>
    </section>
  );
};

export default Home;
