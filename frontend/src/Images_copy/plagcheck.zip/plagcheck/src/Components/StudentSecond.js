import React from "react";
const StudentSecond = () => {
  return (
    <section className="student-home">
      <div className="project-heading">Plag Check</div>
      
      <button>Open</button>
      <button>Submit</button>
      <button>Result</button>
    </section>
  );
};

export default StudentSecond;
