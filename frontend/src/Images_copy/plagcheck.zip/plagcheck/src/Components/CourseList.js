const CourseList = [
  {
    id: "1",
    name: "Compilers",
  },
  {
      id : "2",
      name : "Physics"
  }
];

export default CourseList;