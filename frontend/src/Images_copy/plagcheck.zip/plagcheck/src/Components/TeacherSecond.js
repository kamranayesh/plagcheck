import React from "react";
const TeacherSecond = () => {
  return (
    <section className="student-home">
      <div className="project-heading">Plag Check</div>
      <button>Post New Assignment</button>
      <button>View Submission</button>
      
    </section>
  );
};

export default TeacherSecond;